package project_1_4;

public class Rectangle {

}
